<?php 
var_dump($ShowAll);
?>
<div class="container">
	<h2>Are you sure you want to delete the following course?</h2>
	<table class="table table-condensed">
		<tr>
			<td>Name</td>
			<td>name of the course</td>
		</tr>
		<tr>
			<td>Description</td>
			<td>Description of the course</td>
		</tr>
	</table>
</div>