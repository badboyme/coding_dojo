<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title; ?></title>
    <!-- Latest compiled and minified CSS -->
  <script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>
  $(document).ready(function(){
   $('#mainForm').submit(function(){
    $.post( 
      $('#mainForm').attr('action'),
      $('#mainForm').serialize(),
      function(output){
        $('#messages').append("name: "+output.name+ " age: "+output.age+ "<br />");
      }, "json"
    );
    return false;
   });
  });
  </script>
  </head>
  <body>
